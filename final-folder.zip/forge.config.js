module.exports = {
    plugins: [
        ['@electron-forge/plugin-auto-unpack-natives']
    ]
}
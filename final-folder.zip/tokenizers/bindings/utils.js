const native = require("./native");

module.exports = {
  mergeEncodings: native.utils_mergeEncodings,
  slice: native.utils_slice,
};

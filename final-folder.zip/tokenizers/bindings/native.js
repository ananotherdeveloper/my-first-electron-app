const native = require("../bin-package");
module.exports = native;
